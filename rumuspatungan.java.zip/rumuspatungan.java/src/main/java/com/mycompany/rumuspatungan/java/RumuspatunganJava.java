/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rumuspatungan.java;

/**
 *
 * @author Lenovo
 */
import java.util.Scanner;
public class RumuspatunganJava {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Masukkan Harga: ");
        double harga = scanner.nextDouble();
        
        System.out.println("Masukkan Jumlah Orang: ");
        int jumlahorang = scanner.nextInt();
        
        double hasil = harga / jumlahorang;
        System.out.println("Setiap orang harus membayar: " + hasil);
        
        scanner.close();
    }
}
